/** Statistics information about rnio.
 *
 * @since 1.0
 */
package org.khelekore.rnio.statistics;
